package weather;// Tests for CS5010 Assignment 1: Weather
// By Edward Burke
import org.junit.Before;
import org.junit.Test;
import static org.junit.Assert.assertEquals;

public class WeatherReadingTest {

    private WeatherReading sanFrancisco;
    private WeatherReading sunnyvale;

    // Initializes Objects for testing
    @Before
    public void setUp() {
        sanFrancisco = new WeatherReading(20, 15, 4, 9);
        sunnyvale = new WeatherReading(23, 12, 7, 4);
    }

    // Tests getTemperature()
    @Test
    public void testAirTemp() {
        assertEquals(20, sanFrancisco.getTemperature());
        assertEquals(23, sunnyvale.getTemperature());
    }

    // Tests getDewPoint()
    @Test
    public void testDewPoint() {
        assertEquals(15, sanFrancisco.getDewPoint());
        assertEquals(12, sunnyvale.getDewPoint());
    }

    // Tests getWindSpeed()
    @Test
    public void testWindSpeed() {
        assertEquals(4, sanFrancisco.getWindSpeed());
        assertEquals(7, sunnyvale.getWindSpeed());
    }

    // Tests getTotalRain()
    @Test
    public void testRainfall() {
        assertEquals(9, sanFrancisco.getTotalRain());
        assertEquals(4, sunnyvale.getTotalRain());
    }

    // Tests the overridden toString()
    @Test
    public void testToString() {
        assertEquals("Reading: T = 20, D = 15, v = 4, rain = 9", sanFrancisco.toString());
        assertEquals("Reading: T = 23, D = 12, v = 7, rain = 4", sunnyvale.toString());
    }

    // Tests getRelativeHumidity()
    @Test
    public void testRelativeHumidity() {
        assertEquals(75, sanFrancisco.getRelativeHumidity());
        assertEquals(45, sunnyvale.getRelativeHumidity());
    }

    // Tests getHeatIndex()
    @Test
    public void testHeatIndex() {
        // Note that we are using assertEquals() with a delta value
        // to account for double inaccuracy
        assertEquals(22.254091511064985, sanFrancisco.getHeatIndex(), 0.001);
        assertEquals(25.112149608444998, sunnyvale.getHeatIndex(), 0.001);
    }

    // Tests getWindChill()
    @Test
    public void testWindChill() {
        assertEquals(69.66315193333725, sanFrancisco.getWindChill(), 0.001);
        assertEquals(75.38986151045651, sunnyvale.getWindChill(), 0.001);
    }
}
