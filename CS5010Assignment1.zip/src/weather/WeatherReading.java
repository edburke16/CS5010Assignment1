// CS5010 Assignment 1: Weather
// By Edward Burke

package weather;

// Needed to import Math for the pow() function,
// which helps on the more complex methods
import java.lang.Math;

public class WeatherReading {
    // Variables
    private int airTemp;
    private int dewTemp;
    private int windSpeed;
    private int totalRain;

    // Constructor
    public WeatherReading(int airTemp, int dewTemp, int windSpeed, int totalRain) {
        this.airTemp = airTemp;
        this.dewTemp = dewTemp;
        this.windSpeed = windSpeed;
        this.totalRain = totalRain;
    }

    // Returns the Object as a String
    @Override
    public String toString() {
        return "Reading: T = " + airTemp + ", D = "
                + dewTemp + ", v = " + windSpeed
                + ", rain = " + totalRain;
    }

    // Returns air temperature
    public int getTemperature() {
        return airTemp;
    }

    // Returns dew point
    public int getDewPoint() {
        return dewTemp;
    }

    // Returns wind speed
    public int getWindSpeed() {
        return windSpeed;
    }

    // Returns rainfall
    public int getTotalRain() {
        return totalRain;
    }

    // Returns relative humidity
    public int getRelativeHumidity() {
        return (((airTemp - dewTemp) * 5) - 100) * -1;
    }

    // Returns heat index
    public double getHeatIndex() {
        return -8.78469475556 + (1.61139411 * airTemp)
                + (2.33854883889 * getRelativeHumidity())
                + (-0.14611605 * airTemp * getRelativeHumidity())
                + (-0.012308094 * Math.pow(airTemp, 2))
                + (-0.0164248277778 * Math.pow(getRelativeHumidity(), 2))
                + (0.002211732 * Math.pow(airTemp, 2) * getRelativeHumidity())
                + (0.00072546 * airTemp * Math.pow(getRelativeHumidity(), 2))
                + (-0.000003582 * Math.pow(airTemp, 2)
                * Math.pow(getRelativeHumidity(), 2));
    }

    // Returns wind chill
    public double getWindChill() {
        return 35.74 + (0.6215 * ((airTemp * 1.8) + 32))
                - (35.75 * Math.pow(windSpeed, 0.16))
                + (0.4275 * ((airTemp * 1.8) + 32) * Math.pow(windSpeed, 0.16));
    }
}
